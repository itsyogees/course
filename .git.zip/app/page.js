import React from 'react'
import Navbar from './component/Navbar/Navbar'
import Home from './page/Home/Home'

const page = () => {
  return (
    <div>
    <Navbar/>
    <Home/>
    </div>
  )
}

export default page