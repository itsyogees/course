"use client";

import React, { useState } from "react";
import {
  FaBars,
  FaTimes,
  FaSearch,
  FaRegHeart,
  FaRegUserCircle,
} from "react-icons/fa";
import Image from "next/image"; // Ensure you import from 'next/image'
import styles from "./Navbar.module.scss";

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen((prev) => !prev);
  };

  return (
    <section>
      <div className={styles["navbar-container"]}>
        <nav className={styles.navbar}>
          <div className={styles.logo}>
            <Image src="/image/logo.png" alt="Logo" width={97} height={65} />
            <h2>Education <br /> Platform</h2>
          </div>
          <div className={styles["menu-icon"]} onClick={toggleMenu}>
            {!isMenuOpen ? <FaBars className={styles.icon} /> : null}
          </div>
          <ul
            className={`${styles["nav-items"]} ${
              isMenuOpen ? styles.active : ""
            }`}
          >
            <li>
              <a href="#">Home</a>
            </li>
            <li>
              <a href="#">About</a>
            </li>
            <li>
              <a href="#">Blogs</a>
            </li>
            <li>
              <a href="#">Contact</a>
            </li>
            <li>
              <a href="#">Feedback</a>
            </li>
          </ul>
          <div className={styles["cancel-icon"]} onClick={toggleMenu}>
            {isMenuOpen ? <FaTimes className={styles.icon} /> : null}
          </div>

          {/* Right side icons and text */}
          <div className={styles["right-menu"]}>
            <FaSearch className={styles.icon} />
            <FaRegHeart className={styles.icon} />
            <FaRegUserCircle className={styles.icon} />
            <span className={styles["hello-text"]}>Hello,</span>
            <span className={styles["sign-in-text"]}>Sign In</span>
          </div>
        </nav>
      </div>
    </section>
  );
};

export default Navbar;
