import React from "react";
import styles from "./Home.module.scss";

const Home = () => {
  return (
    <>
      <div className={styles.home}>
        <div className={styles.homeContainer}>
          <div className={styles.homeContainerDiv}>
            <h2>Lorem ipsum dolor sit amet, consectetur</h2>
            <p>
              Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
              eiusmod tempor incididunt ut labore .
            </p>
            <button className={styles.btn}>Join Now</button>
          </div>
        </div>
      </div>
      <div className={styles.homeContent}>
        <div className={styles.homeContentContainer}>
          <div className={styles.homeCard}>
            <div className={styles.homeCardContent}>
              <h2>Courses</h2>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore.
              </p>
              <button className={styles.readbtn}>Read More</button>
            </div>
          </div>

          <div className={styles.homeCard}>
            <div className={styles.homeCardContent}>
              <h2>Graduate</h2>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore.
              </p>
              <button className={styles.readbtn}>Read More</button>
            </div>
          </div>

          <div className={styles.homeCard}>
            <div className={styles.homeCardContent}>
              <h2>Programs</h2>
              <p>
                Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do
                eiusmod tempor incididunt ut labore.
              </p>
              <button className={styles.readbtn}>Read More</button>
            </div>
          </div>

          <div className={`${styles.homeCard} ${styles.card2}`}>
            <h3>YOUR ARE WELCOME</h3>
            <p>Discover our Top school Child Benefits</p>
            <button className={styles.findbtn}>FIND OUT MORE </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default Home;
