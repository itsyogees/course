import React from 'react'
import Navbar from './component/Navbar/Navbar'
import Home from './page/Home/Home'
import About from './page/About/About'
import Footer from './component/Footer/Footer'
import Events from './page/Events/Events'
import Courses from './page/Courses/Courses'
import CoursesDetails from './page/Courses/CoursesDetails/CoursesDetails'


const page = () => {
  return (
    <div>
    <Navbar/>
    <Home/>
    {/* <About/> */}
   {/*  <Events/>
    <Courses/>
    <CoursesDetails/> */}
    <Footer/>
    </div>
  )
}

export default page